# USWAG: Unified System for Work and Growth
**Project Proposal · Advanced Relational Database Systems (Final Project)**
Proponents: Bryan Jay Lumabas and Claire Pillo · © 2026 Bryan Jay Lumabas and Claire Pillo

The database is the project. The website only presents it.

## What is inside
| Folder / file | Contents |
|---|---|
| `database/uswag_db.sql` | Final MySQL / MariaDB script: 12 tables, 9 views, 18 procedures, 26 triggers, sample data and 14 queries. |
| `diagrams/` | `uswag_erd.mmd` (Mermaid source), `uswag_erd_crowsfoot.svg` and `.png` (Crow’s Foot ERD, same source). |
| `documents/` | Business Rules, Normalization Proofs and Performance Report (PDF, with `source/*.md`). |
| `presentation/` | `USWAG_Project_Proposal.docx` and `.pdf`, `USWAG_Slides_Plain.pptx`, `USWAG_Slides_Interface.pptx`, `screenshots/`. All are 16:9. |
| `website/` | Six pages: `index.html` (the dedication, the entry page), `phase1-proposal.html` to `phase5-deliverables.html`, plus `styles.css`, `script.js`, `theme.js`, `data.js`, `assets/`. It also holds its own copy of `database/`, `diagrams/`, `documents/` and `presentation/`, so it works alone. |

## How to run
1. **Database:** start Laragon, open HeidiSQL, choose *File > Run SQL file* and pick `database/uswag_db.sql`. Or run `mysql -uroot < database/uswag_db.sql`. The script drops and recreates `uswag_db`.
2. **Website:** open `website/index.html` in a browser. The ERD needs internet to draw live; offline it shows the saved SVG.
3. **Present:** press **▶ Present** (or the P key). Arrow keys move between slides and phases, Esc exits.
4. **Dark mode:** use the switch at the bottom left of Phase 1. The choice is remembered.
5. **Print:** Ctrl+P prints one 16:9 slide per page. Turn on *Background graphics* for the best result.
6. **Dedication:** the gold button at the bottom of Phase 5 opens `index.html`.

## Database notes
- The database enforces every rule, so any frontend can change without touching the script.
- Capital can change only through the ledger (`sp_capital_move`).
- Tested on MariaDB 10.11: imports with 0 errors, 12 tables, 9 views, 18 procedures, 26 triggers. Demo flow: capital 5,000 + sales 2,600 − expense 1,500 = 6,100; stock 500 → 450.
- Index test (50,000 sales / 100,000 lines): 146 ms → 2.5 ms.
- Known limit: registration leaves `Sellers.first_name` and `last_name` unfilled, so some reports show the username.

## Deploy (GitHub Pages or Cloudflare Pages)
- Cloudflare Pages: build command empty, output directory `website`.
- GitHub Pages: publish the repository; the site is at `/website/`. `.nojekyll` is included.
- All links inside `website/` are relative and stay inside `website/`.
